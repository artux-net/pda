package net.artux.pda.Models.profile;

import java.util.HashMap;

public class UpdateData {

    public HashMap<String, String> values = new HashMap<>();

}
