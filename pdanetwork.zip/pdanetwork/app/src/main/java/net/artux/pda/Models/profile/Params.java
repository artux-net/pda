package net.artux.pda.Models.profile;

import java.util.HashMap;
import java.util.List;

public class Params {
    
    public List<String> params = null;
    public HashMap<String, Integer> values = null;

}
