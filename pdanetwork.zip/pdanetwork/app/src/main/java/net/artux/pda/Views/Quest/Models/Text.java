package net.artux.pda.Views.Quest.Models;

import java.util.HashMap;
import java.util.List;

public class Text {

    public String text;
    public HashMap<String, List<String>> condition;

}
