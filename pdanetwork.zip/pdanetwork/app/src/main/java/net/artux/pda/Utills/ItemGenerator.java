package net.artux.pda.Utills;

import net.artux.pda.Models.profile.Item;

public class ItemGenerator {


    public Item getItem(int id){
        return null;
    }


}
