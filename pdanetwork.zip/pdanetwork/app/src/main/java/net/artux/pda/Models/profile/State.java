
package net.artux.pda.Models.profile;


public class State {


}
