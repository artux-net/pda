package net.artux.pda.Views.Quest.Models;

public class Armor {
}
