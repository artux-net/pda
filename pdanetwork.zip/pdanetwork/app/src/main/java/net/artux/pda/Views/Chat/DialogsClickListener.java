package net.artux.pda.Views.Chat;

import net.artux.pda.Models.Dialog;

interface DialogsClickListener{
    void onClick(Dialog dialog);
}
