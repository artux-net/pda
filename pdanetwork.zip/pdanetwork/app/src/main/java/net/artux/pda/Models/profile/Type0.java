
package net.artux.pda.Models.profile;


public class Type0 extends Item {


}
