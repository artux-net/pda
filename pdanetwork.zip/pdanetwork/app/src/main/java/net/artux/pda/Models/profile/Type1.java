package net.artux.pda.Models.profile;

public class Type1 extends Item{


}
