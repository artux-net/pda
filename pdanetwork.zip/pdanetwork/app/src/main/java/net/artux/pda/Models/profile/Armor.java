
package net.artux.pda.Models.profile;


public class Armor extends Item {


}
