package net.artux.pda.Views.News;

import com.prof.rssparser.Article;

interface NewsClickListener {
    void onClick(Article article);
}
