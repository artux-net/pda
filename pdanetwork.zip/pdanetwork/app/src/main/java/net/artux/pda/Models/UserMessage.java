package net.artux.pda.Models;

public class UserMessage {

    public String senderLogin;
    public String message;
    public String time;
    public int groupId;
    public int avatarId;
    public int pdaId;

}
