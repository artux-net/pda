
package net.artux.pda.Models.profile;


public class Detector extends Item {


}
